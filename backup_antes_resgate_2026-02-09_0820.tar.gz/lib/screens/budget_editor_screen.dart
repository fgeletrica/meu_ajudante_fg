import 'dart:convert';
import 'dart:typed_data';
import '../services/pro_guard.dart';
import 'package:meu_ajudante_fg/widgets/pro_lock_tile.dart';
import '../services/service_catalog.dart';
import 'package:flutter/material.dart';
import 'package:meu_ajudante_fg/routes/app_routes.dart';
import 'package:meu_ajudante_fg/services/pdf_limits.dart';
import 'package:flutter/services.dart';
import 'dart:developer' show identityHashCode;
import 'package:share_plus/share_plus.dart';
import 'package:open_filex/open_filex.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/budget_models.dart';
import '../services/budget_store.dart';
import '../services/pdf_service.dart';
import '../services/materials_store.dart';
import '../services/service_templates.dart';
import 'service_picker_screen.dart';
import 'signature_screen.dart';
import 'services_pro_screen.dart';
import '../routes/app_routes.dart';
import '../services/pdf_limits.dart';

class BudgetEditorScreen extends StatefulWidget {
  final BudgetDoc doc;
  const BudgetEditorScreen({super.key, required this.doc});

  @override
  State<BudgetEditorScreen> createState() => _BudgetEditorScreenState();
}

class _BudgetEditorScreenState extends State<BudgetEditorScreen> {
  Future<void> _openPaywall() async {
    if (!mounted) return;
    Navigator.of(context).pushNamed(AppRoutes.paywall);
  }

  static const String _kFreeFirstPdfDone = 'free_first_pdf_done_v1';
  bool? _freePdfDoneCache;

  Future<bool> _isFreePdfDone() async {
    if (_freePdfDoneCache != null) return _freePdfDoneCache!;
    final sp = await SharedPreferences.getInstance();
    _freePdfDoneCache = sp.getBool(_kFreeFirstPdfDone) ?? false;
    return _freePdfDoneCache!;
  }

  Future<void> _markFreePdfDone() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool(_kFreeFirstPdfDone, true);
    _freePdfDoneCache = true;
  }

  late BudgetDoc doc;

  final clientCtrl = TextEditingController();
  // ---- controllers persistentes (pra não bugar digitação) ----
  final Map<String, TextEditingController> _fieldCtrs = {};

  TextEditingController _ctr(String key, String initial) {
    final c =
        _fieldCtrs.putIfAbsent(key, () => TextEditingController(text: initial));
    return c;
  }

  void _dropCtrPrefix(String prefix) {
    final keys = _fieldCtrs.keys.where((k) => k.startsWith(prefix)).toList();
    for (final k in keys) {
      _fieldCtrs[k]?.dispose();
      _fieldCtrs.remove(k);
    }
  }

  final marginCtrl = TextEditingController();

  bool showMaterials = false;
  bool showServices = true;

  @override
  void initState() {
    super.initState();
    doc = widget.doc;
    clientCtrl.text = doc.clientName;
    marginCtrl.text = doc.marginValue.toStringAsFixed(2);
  }

  @override
  void dispose() {
    for (final c in _fieldCtrs.values) {
      c.dispose();
    }
    _fieldCtrs.clear();
    clientCtrl.dispose();
    marginCtrl.dispose();
    super.dispose();
  }

  Future<bool> _isFreeDone() async {
    return false; // FREE ilimitado
  }

  double toDouble(String s) =>
      double.tryParse(s.replaceAll(',', '.').trim()) ?? 0.0;
  String money(double v) => "R\$ ${v.toStringAsFixed(2)}";

  InputDecoration dec(String label) => InputDecoration(
        labelText: label,
        filled: true,
        fillColor: const Color(0xFF141A22),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      );

  void addMaterial() => setState(() => doc.materials
      .add(BudgetItem(name: "Material", qty: 1, unit: "un", unitPrice: 0)));

  Future<void> _addMaterialGuarded() async {
    addMaterial();
  }

  void _addServiceTemplate(ServiceTemplate t) {
    setState(() {
      doc.services
          .add(BudgetServiceLine(name: t.title, price: t.priceSuggested));
    });
  }

  Future<void> _openServicePicker() async {
    final picked = await Navigator.push<ServiceTemplate?>(
      context,
      MaterialPageRoute(builder: (_) => const ServicePickerScreen()),
    );
    if (picked == null) return;
    _addServiceTemplate(picked);
  }

  void addServiceManual() => setState(
      () => doc.services.add(BudgetServiceLine(name: "Serviço", price: 0)));

  void _openServiceCatalog() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(
          children: serviceCatalog.map((s) {
            return ListTile(
              leading: Icon(s.icon),
              title: Text(s.name),
              trailing: Text('R\$ ' + s.price.toStringAsFixed(2)),
              onTap: () {
                setState(() {
                  doc.services
                      .add(BudgetServiceLine(name: s.name, price: s.price));
                });
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  Future<void> save() async {
    doc.clientName = clientCtrl.text.trim();
    doc.marginValue = toDouble(marginCtrl.text);

    await BudgetStore.upsert(doc);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text("Orçamento salvo ✅")));
    setState(() {});
  }

  Future<void> signOptional() async {
    final b64 = await Navigator.push<String?>(
      context,
      MaterialPageRoute(builder: (_) => const SignatureScreen()),
    );
    if (b64 == null) return;
    setState(() => doc.signatureB64 = b64);
    await save();
  }

  Future<void> exportPdf({required bool share}) async {
    // 🔧 garante preços antes do PDF
    try {
      await applyMaterialPricesFromDb();
    } catch (_) {}

    final hasPro = await ProGuard.hasPro();

    if (!hasPro) {
      final left = await PdfLimits.freeRemainingThisMonth();
      if (left <= 0) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text(
                  "Limite do FREE: 3 PDFs/mês. Vire PRO para liberar ilimitado 🚀")),
        );
        await _openPaywall();
        return;
      }
    }

    // mantém sua geração normal
    Uint8List? signatureBytes;
    try {
      final b64 = (doc.signatureB64 ?? '').trim();
      if (b64.isNotEmpty) {
        signatureBytes = base64Decode(b64);
      }
    } catch (_) {}

    final file = await PdfService.generateBudgetPdf(
      doc: doc,
      hasPro: hasPro,
      signatureBytes: signatureBytes,
    );
    if (!hasPro) {
      await PdfLimits.markFreePdfGenerated();
    }

    if (!mounted) return;
    if (share) {
      await PdfService.sharePdf(file);
    } else {
      await PdfService.openPdf(file);
    }

    setState(() {}); // só pra atualizar UI/contador
  }

  Future<void> applyMaterialPricesFromDb() async {
    final db = await MaterialsStore.load();
    final hasProNow = false;
    final done = await _isFreeDone();
    final locked = (!hasProNow && done);
    if (db.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content:
              Text("Cadastre materiais em: Ferramentas → Meus Materiais")));
      return;
    }

    int hits = 0;
    for (final it in doc.materials) {
      final name = it.name.toLowerCase().trim();
      if (name.isEmpty) continue;

      MaterialDbItem? best;
      for (final m in db) {
        final mn = m.name.toLowerCase().trim();
        if (mn.isEmpty) continue;
        if (name.contains(mn) || mn.contains(name)) {
          best = m;
          break;
        }
      }
      if (best != null) {
        it.unit = best!.unit;
        it.unitPrice = best!.price;
        hits++;
      }
    }

    if (!mounted) return;
    setState(() {});
    _dropCtrPrefix('mat_');
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Preços aplicados em $hits item(ns).")));
  }

  Future<void> addServiceFromProWizard() async {
    final has = false;
    if (!has) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Recurso PRO — desbloqueie para usar ✅")));
      Navigator.of(context).pushNamed(AppRoutes.paywall);
      return;
    }

    if (!mounted) return;
    final r = await Navigator.push<Map?>(
      context,
      MaterialPageRoute(builder: (_) => const ServicesProScreen()),
    );
    if (r == null) return;

    final name = (r['name'] ?? '').toString();
    final price = (r['price'] is num) ? (r['price'] as num).toDouble() : 0.0;

    if (name.trim().isEmpty) return;
    setState(() =>
        doc.services.add(BudgetServiceLine(name: name.trim(), price: price)));
  }

  bool get hasSignature =>
      doc.signatureB64 != null && doc.signatureB64!.trim().isNotEmpty;

  @override
  Future<void> _pickMaterialFromDb(BuildContext context, dynamic it) async {
    final hasProNow = false;
    final freeDone = await _isFreePdfDone();
    final db = await MaterialsStore.load();
    final hasPro = false;
    final done = await _isFreeDone();
    final locked = (!hasProNow && done);
    if (!mounted) return;
    if (db.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Cadastre materiais em Meus Materiais primeiro.')));
      return;
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Selecionar material",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 12),
            Flexible(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: db.length,
                itemBuilder: (_, i) {
                  final m = db[i];
                  return ListTile(
                    leading: const Icon(Icons.inventory_2),
                    title: Text(m.name),
                    subtitle: Text(
                        "Un: ${m.unit} • R\$ ${m.price.toStringAsFixed(2)}"),
                    onTap: () {
                      if (locked) {
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text(
                                  "FREE: após o 1º PDF, selecionar materiais é PRO ✅")),
                        );
                        Navigator.of(context).pushNamed(AppRoutes.paywall);
                        return;
                      }
                      setState(() {
                        it.name = m.name;
                        it.unit = m.unit;
                        it.unitPrice = m.price;
                      });
                      Navigator.pop(context);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget build(BuildContext context) {
    final canGenerate = clientCtrl.text.trim().isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Orçamento"),
        actions: [
          IconButton(
            tooltip: "Salvar",
            onPressed: save,
            icon: const Icon(Icons.save),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (doc.originTitle != null)
            _card(
              child: Text(
                "Origem: ${doc.originTitle} • ${doc.originPowerW?.toStringAsFixed(0) ?? '—'}W • ${doc.originVoltage ?? '—'}V",
                style: const TextStyle(color: Colors.white70),
              ),
            ),
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Cliente",
                    style:
                        TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 10),
                TextField(
                    controller: clientCtrl, decoration: dec("Nome do cliente")),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: OutlinedButton.icon(
                    onPressed: signOptional,
                    icon: Icon(hasSignature ? Icons.verified : Icons.edit),
                    label: Text(hasSignature
                        ? "Assinado ✅ (opcional)"
                        : "Assinar (opcional)"),
                  ),
                ),
              ],
            ),
          ),
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text("Serviços",
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 16)),
                    ),
                    TextButton(
                      onPressed: () =>
                          setState(() => showServices = !showServices),
                      child: Text(showServices ? "Ocultar" : "Mostrar"),
                    ),
                  ],
                ),
                if (showServices) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: addServiceManual,
                          icon: const Icon(Icons.add),
                          label: const Text("Adicionar manual"),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: addServiceFromProWizard,
                          icon: const Icon(Icons.auto_fix_high),
                          label: const Text("Serviços PRO"),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: OutlinedButton.icon(
                      onPressed: _openServiceCatalog,
                      icon: const Icon(Icons.playlist_add),
                      label: const Text("Adicionar do catálogo"),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const SizedBox(height: 10),
                  ...doc.services.asMap().entries.map((e) {
                    final i = e.key;
                    final s = e.value;
                    return _card(
                      child: Column(
                        children: [
                          _head("Serviço",
                              onDelete: () =>
                                  setState(() => doc.services.removeAt(i))),
                          TextField(
                            controller:
                                _ctr('svc_name_${identityHashCode(s)}', s.name),
                            decoration: dec("Nome do serviço"),
                            onChanged: (v) => s.name = v,
                          ),
                          const SizedBox(height: 8),
                          TextField(
                            controller: _ctr('svc_price_${identityHashCode(s)}',
                                s.price.toStringAsFixed(2)),
                            decoration: dec("Valor (R\$)"),
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            onChanged: (v) =>
                                setState(() => s.price = toDouble(v)),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
              ],
            ),
          ),
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text("Materiais (opcional)",
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 16)),
                    ),
                    TextButton(
                      onPressed: () =>
                          setState(() => showMaterials = !showMaterials),
                      child: Text(showMaterials ? "Ocultar" : "Mostrar"),
                    ),
                  ],
                ),
                if (showMaterials) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _addMaterialGuarded,
                          icon: const Icon(Icons.add),
                          label: const Text("Adicionar material"),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: applyMaterialPricesFromDb,
                          icon: const Icon(Icons.auto_fix_high),
                          label: const Text("Aplicar preços"),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ...doc.materials.asMap().entries.map((e) {
                    final i = e.key;
                    final it = e.value;
                    return _card(
                      child: Column(
                        children: [
                          _head("Material",
                              onDelete: () =>
                                  setState(() => doc.materials.removeAt(i))),
                          Material(
                            color: Colors.transparent,
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () => _pickMaterialFromDb(context, it),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFF141A22),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                      color: const Color(0xFF2B2F3A)),
                                ),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 12),
                                child: Row(
                                  children: [
                                    const Icon(Icons.inventory_2,
                                        size: 18, color: Colors.white70),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        (it.name.trim().isEmpty)
                                            ? 'Selecionar material'
                                            : it.name,
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w800),
                                      ),
                                    ),
                                    const Icon(Icons.arrow_drop_down,
                                        color: Colors.white70),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: TextField(
                                  controller: _ctr(
                                      'mat_qty_${identityHashCode(it)}',
                                      it.qty.toStringAsFixed(2)),
                                  decoration: dec("Qtd"),
                                  keyboardType:
                                      const TextInputType.numberWithOptions(
                                          decimal: true),
                                  onChanged: (v) =>
                                      setState(() => it.qty = toDouble(v)),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: TextField(
                                  controller: _ctr(
                                      'mat_unit_${identityHashCode(it)}',
                                      it.unit),
                                  decoration: dec("Un"),
                                  onChanged: (v) => setState(() => it.unit = v),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          TextField(
                            controller: _ctr(
                                'mat_price_${identityHashCode(it)}',
                                it.unitPrice.toStringAsFixed(2)),
                            decoration: dec("Preço unitário (R\$)"),
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            onChanged: (v) =>
                                setState(() => it.unitPrice = toDouble(v)),
                          ),
                          const SizedBox(height: 8),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Text("Total: ${money(it.total)}",
                                style: const TextStyle(
                                    fontWeight: FontWeight.w900)),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
              ],
            ),
          ),
          _card(
            child: Column(
              children: [
                const SizedBox.shrink(),
                const SizedBox(height: 10),
                _row("Subtotal materiais", money(doc.subtotalMaterials)),
                _row("Subtotal serviços", money(doc.subtotalServices)),
                _row("Margem", money(doc.marginAmount)),
                const Divider(),
                _row("TOTAL", money(doc.total), strong: true),
              ],
            ),
          ),
          FutureBuilder<bool>(
            future: Future.value(false),
            builder: (context, snap) {
              final pro = snap.data ?? false;
              return Text(
                pro
                    ? "PRO ativo: PDF sai limpo ✅"
                    : "FREE: PDF sai com marca d'água ✅ (PRO remove)",
                style: const TextStyle(color: Colors.white70),
              );
            },
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: canGenerate ? () => exportPdf(share: false) : null,
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text("Gerar PDF"),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: canGenerate ? () => exportPdf(share: true) : null,
                  icon: const Icon(Icons.share),
                  label: const Text("Enviar WhatsApp"),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF141A22),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF2B2F3A)),
      ),
      child: child,
    );
  }

  Widget _head(String title, {required VoidCallback onDelete}) {
    return Row(
      children: [
        const Icon(Icons.drag_indicator),
        const SizedBox(width: 8),
        Expanded(
            child: Text(title,
                style: const TextStyle(fontWeight: FontWeight.w900))),
        IconButton(onPressed: onDelete, icon: const Icon(Icons.delete)),
      ],
    );
  }

  Widget _row(String a, String b, {bool strong = false}) {
    final style = TextStyle(
      color: strong ? Colors.white : Colors.white70,
      fontWeight: strong ? FontWeight.w900 : FontWeight.w600,
      fontSize: strong ? 16 : 14,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(a, style: style)),
          Text(b, style: style),
        ],
      ),
    );
  }
}

void openServiceCatalog(BuildContext context, Function(String, double) onAdd) {
  showModalBottomSheet(
    context: context,
    builder: (_) => ListView(
      children: serviceCatalog.map((s) {
        return ListTile(
          leading: const Icon(Icons.design_services),
          title: Text(s.name),
          trailing: Text('R\$ ${s.price.toStringAsFixed(2)}'),
          onTap: () {
            onAdd(s.name, s.price);
            Navigator.pop(context);
          },
        );
      }).toList(),
    ),
  );
}
