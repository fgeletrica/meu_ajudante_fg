// Desktop / mobile: não faz nada (o dashboard é web)
void downloadCsvWeb(String filename, String content) {}
